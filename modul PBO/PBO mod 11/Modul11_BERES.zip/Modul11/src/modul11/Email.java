/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modul11;

import java.io.*;
import java.time.LocalDate;

/**
 *
 * @author aysla
 */
public class Email implements Email_IO, Serializable{
    private int id;
    private String sender;
    private String subject;
    private String content; 
    private LocalDate date;
    private boolean starred;

    public Email(int id, String sender, String subject, String content, LocalDate date, boolean starred) {
        this.id = id;
        this.sender = sender;
        this.subject = subject;
        this.content = content;
        this.date = date;
        this.starred = starred;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public boolean isStarred() {
        return starred;
    }

    public void setStarred(boolean starred) {
        this.starred = starred;
    }
    
    public void display(){
        System.out.printf("%-25s %25s %n", this.getSender(), this.date);
        System.out.println(this.getSubject());
        if (isStarred()){
            System.out.printf("%-25s %25s %n", this.getContent(), "*");
        }else{
            System.out.printf("%-25s %25s %n", this.getContent(), "x");
        }
        System.out.println("");
        
        
    }
    
    /*
    Implementasi method save dengan menyimpan 
    hanya value dari atribut sender, content, dan starred  
    */
    @Override
    public void save(ObjectOutput out){
        try{
            Email m = new Email(0, this.getSender(), null, this.getContent(), null, this.isStarred());
            out.writeObject(m);
            out.flush();
        }catch(IOException e){
            System.err.println("error "+e);
        }
    }
    /*
    Implementasi method load dengan mengembalikan hanya value 
    dari atribut sender, content, dan starred  
    */
    @Override
    public void load(ObjectInput in){
        Email m = null;
         try{
            while((m = (Email) in.readObject()) != null){
                m.display();
            }
        }catch(IOException e){
            System.exit(0);
        }catch(Exception e){
            System.exit(0);
        }
    }
    
    
}
