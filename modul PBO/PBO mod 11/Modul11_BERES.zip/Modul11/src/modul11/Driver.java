/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modul11;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author aysla
 */
public class Driver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        // TODO code application logic here
        ArrayList<Email> mails= new ArrayList<>();
        mails.add(new Email(1, "Eren Yeager", "Titan 1", "Hello, how are you?", LocalDate.of(2021, 5, 1), false));
        mails.add(new Email(2, "Armin Arlert", "Titan 2", "Let's meet tomorrow!", LocalDate.of(2021, 4, 29), false));
        mails.add(new Email(3, "Mikasa Ackerman", "Titan 3", "Project deadline", LocalDate.of(2021,4,30), true));
        
        FileOutputStream fos = new FileOutputStream("email.dat");
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        for (Email e : mails){
            e.save(oos);
        }
        System.out.println("Berhasil menyimpan ke email.dat");
        
        try{
            System.out.println("Mengambil data dari email.dat...");
            FileInputStream fis = new FileInputStream("email.dat");
            ObjectInputStream ois = new ObjectInputStream(fis);
            System.out.println("Berhasil mengambil data dari email.dat");
            System.out.println("Email: \n");
            for(Email m2 : mails){
                m2.load(ois);
            }
        }catch(IOException e){
            e.printStackTrace();
        }catch(Exception e){
            e.printStackTrace();
        }
        
        
    }
    
}
